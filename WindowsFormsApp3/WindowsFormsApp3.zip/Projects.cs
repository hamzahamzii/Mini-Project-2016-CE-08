﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Projects : Form
    {
        public String conURL = "Data Source=ROHIT-MEHRA;Initial Catalog=ProjectA;Persist Security Info=True;User ID=sa;Password=secretpassword";
        public Projects()
        {
            InitializeComponent();
        }

        private void Projects_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(conURL);
                conn.Open();
                DataTable dt = new DataTable();
                SqlDataAdapter adapt = new SqlDataAdapter("SELECT * FROM Project", conn);
                adapt.Fill(dt);
                ProjectsGridView.DataSource = dt;
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }

        private void ProjectsGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(conURL);
                conn.Open();
                DataTable dt = new DataTable();
                SqlDataAdapter adapt = new SqlDataAdapter("SELECT * FROM Project", conn);
                adapt.Fill(dt);
                ProjectsGridView.DataSource = dt;
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }

        private void AddProjectsBtn_Click(object sender, EventArgs e)
        {
            AddProject form = new AddProject();
            form.Show();
            this.Hide();
        }

        private void DeleteProjectBtn_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(conURL);
            conn.Open();

            if (ProjectsGridView.SelectedCells.Count != 0)
            {
                int row = ProjectsGridView.SelectedCells[0].RowIndex;
                String delStdCMD = String.Format("DELETE FROM Project WHERE Id = '{0}'", Convert.ToInt32(ProjectsGridView.Rows[row].Cells[0].Value));
                SqlCommand delStdCommand = new SqlCommand(delStdCMD, conn);
                int count = delStdCommand.ExecuteNonQuery();
                Projects form = new Projects();
                this.Hide();
                form.Show();
            }
        }

        private void UpdateProjectBtn_Click(object sender, EventArgs e)
        {
            if (ProjectsGridView.SelectedCells.Count != 0)
            {
                int row = ProjectsGridView.SelectedCells[0].RowIndex;
                int id = Convert.ToInt32(ProjectsGridView.Rows[row].Cells[0].Value);
                AddProject form = new AddProject(id);
                form.Show();
                this.Hide();
            }
        }

        private void BackProjectBtn_Click(object sender, EventArgs e)
        {
            MainPage form = new MainPage();
            form.Show();
            this.Hide();
        }
    }
}
